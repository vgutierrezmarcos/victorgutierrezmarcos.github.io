# Skill ligera

Esta copia de la skill no lleva el material exclusivo (temas revisados, fichas, guía del dictamen ni canon): se lee con las herramientas del conector «Prepara con Claude» (`references/conector.md`: `listar_temas_revisados`, `leer_tema`, `leer_ficha`, `leer_guia_dictamen`). Si el conector no está activo, dilo en una línea y trabaja con los índices de `references/temario/` y conocimiento general.
